function gerarAcesso() {
    const inputElement = document.getElementById('nome');
    const divErro = document.getElementById('mensagemErro');
    const painelResultado = document.getElementById('painelResultado');
    
    const inputNome = inputElement ? inputElement.value : '';
    
    divErro.innerText = '';
    painelResultado.style.display = 'none';

    
    if (inputNome.startsWith(' ') || inputNome.endsWith(' ')) {
        divErro.innerText = 'Não pode haver espaços no início ou no final do nome.';
        return;
    }

 15 
    if (inputNome.length < 15) {
        divErro.innerText = 'O nome deve ter no mínimo 15 caracteres.';
        return;
    }

   
    if (inputNome.includes('  ')) {
        divErro.innerText = 'Deve existir apenas 1 espaço entre os nomes/sobrenomes.';
        return;
    }


    const partes = inputNome.split(' ');

    if (partes.length < 2) {
        divErro.innerText = 'O nome deve conter pelo menos 1 sobrenome.';
        return;
    }


    let login = '';
    for (let i = 0; i < partes.length; i++) {
        if (partes[i].length > 0) {
            login += partes[i].charAt(0).toUpperCase();
        }
    }

    let senha = '';
    for (let i = 0; i < login.length; i++) {
        const codigoASCII = login.charCodeAt(i).toString();
        senha += codigoASCII.charAt(0);
    }

  
    document.getElementById('resLogin').innerText = login;
    document.getElementById('resSenha').innerText = senha;
    painelResultado.style.display = 'block';
}